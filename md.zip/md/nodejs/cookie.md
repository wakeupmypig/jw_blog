## 1.cookie介绍
储存在用户本地终端上的数据
为了辨别用户身份、进行跟踪而储存在用户本地终端上的数据（通常经过加密）。
## 2.使用cookie
1. 客户端第一次访问服务器的时候服务器通过响应头向客户端发送Cookie,属性之间用分号空格分隔
    ```javascript
    var http = require('http');
    http.createServer(function (req,res) {
        if(req.url=='/write'){
            res.setHeader('Set-Cookie',['name=zfpx; domain=.zfpx.cn','age=7']);
            res.end('write');
        }
    }).listen(8080);
    ```

2. 客户端发送的cookie，属性之间用分号空格分隔

    ```javascript
    var http = require('http');
    var querystring = require('querystring')
    http.createServer(function (req,res) {
        if(req.url=='/read'){
        //"name=zfpx; age=7"
             res.end(JSON.stringify(querystring.parse(req.headers['cookie'],'; ')));
             
        }
    }).listen(8080);
    ```  
    
## 3.cookie属性
| 属性       | 含义         |
| ------------- |:-------------:|
| name=value      | 多组以数组形式，存储key/value |
| Path      | 默认是/,匹配到后发送cookie|
| secure      | 当 secure 值为 true 时，cookie 在 HTTP 中是无效，在 HTTPS 中才有效|
| Domain      | 默认是当前域名,可以用.表示任意      |
| maxAge | 最大失效时间(秒),设置在多少秒后失效     |
| Expires | 过期时间(秒)，在设置的某个时间点后该 Cookie 就会失效，如 expires=(new Date(Date.now()+4000)).toGMTString() |
| httpOnly | 如果在COOKIE中设置了httpOnly属性，则通过程序(JS脚本)将无法读取到COOKIE信息，防止XSS攻击产生 |

## 4.express向客户端发送cookie
### 4.1 安装cookie-parser
```javascript
$ npm install cookie-parser
```
### 4.2 设置cookie
```javascript
res.cookie(name,value,[options]);
```
### 4.3 获取cookie
```javascript
req.cookies
```
### 4.4 express中的使用
```javascript
var express = require('express');
var app = express();
var cookieParser = require('cookie-parser');
app.use(cookieParser());
app.get('/write', function (req,res) {
    res.cookie('name','zfpx');
    res.send('');
});
app.get('/read', function (req,res) {
    res.clearCookie('name');//清除cookie
    res.send(req.cookies); 
    
});
```
### 4.5 设置cookie的实现
```javascript
function cookieParser(){
    return function (req,res,next) {
        var arr = [];
        res.cookie = function (name,value,options) {
            arr.push(`${name}=${value}`);
            res.setHeader('Set-Cookie',arr);
        }
        req.cookies = querystring.parse(req.headers['cookie'],'; ')
        next();
    }
}
app.use(cookieParser());
```
### 4.6 选项参数
options选项  

1. 设置domain，在当前域名下访问cookie
```javascript 
res.cookie('name','zfpx',{domain:'a.zfpx.cn'});
```
2. 设置path，在其他路径下无法访问cookie
```javascript 
res.cookie('name','zfpx',{path:'/read'});
```
3. 设置expires,给定绝对时间
```javascript 
res.cookie('name','zfpx',{expires:new Date(Date.now()+4000)});
```
4. 设置maxAge,给定相对时间(毫秒)
```javascript
res.cookie('name','zfpx',{maxAge:2000});
```
5. httpOnly客户端不能设置cookie
```javascript
res.cookie('name','zfpx',{httpOnly:true});
```
6. secure只能通过https进行访问
```javascript
res.cookie('name','zfpx',{secure:true});
```  

## 5.加密
通过crypto来进行加密    

1. md5加密(散列算法)  

    ```javascript
    var crypto = require('crypto');
    console.log(crypto.getHashes());
    var md5 = crypto.createHash('md5');
    var result = md5.update('hello').digest('hex');
    console.log(result);
    ```      

2. HMAC(散列算法与密钥结合)  

    ```javascript
    var crypto = require('crypto');
    var hmac = crypto.createHmac('sha256','jw');
    var md5Sum = hmac.update('hello').digest('hex');
    console.log(md5Sum);
    ``` 

## 6.对访问次数进行加密
```javascript 
var express = require('express');
var app = express();
var cookieParser = require('cookie-parser');
app.use(cookieParser('jw'));
app.get('/visit', function (req,res) {
    var visit = req.signedCookies.visit;
    if(visit){
        visit++;
    }else{
        visit = 1;
    }
    res.cookie('visit',visit,{signed:true});
    res.send(`你是${visit}次访问`);
});
app.listen(8080);
```
### 6.1 加密的实现
```javascript
function sha256(value,flag){
    var crypto = require('crypto');
    return value+'.'+crypto.createHmac('sha256',flag).update(value).digest('base64').replace(/\=/g,'');
}
```
## 7.控制权限
```javascript
var express = require('express');
var app = express();
var path = require('path');
app.set('view engine','html');
app.set('views',path.resolve('views'));
app.engine('html',require('ejs').__express);
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
app.use(cookieParser());
app.use(bodyParser.urlencoded({extended:true}));
var flag = true;
app.get('/login', function (req,res) {
    res.render('login',{title:'登陆',flag:flag})
});
app.post('/login', function (req,res) {
    if(req.body.username){
        res.cookie('username',req.body.username);
        flag = false;
        res.redirect('/user');
    }else{
        res.redirect('back');
    }
});
app.get('/user', function (req,res) {
    if(req.cookies.username){
        res.render('user',{title:'用户列表',username:req.cookies.username})
    }else{
        res.redirect('/');
    }
});
app.get('/', function (req,res) {
    res.render('index',{title:'首页'})
});
app.get('/logout', function (req,res) {
    res.clearCookie('username');
    flag=true;
    res.redirect('/login');
});
app.listen(8080);
```
## 8. 自动登录
服务器端设置cookie
```javascript
var express = require('express');
var app = express();
var path = require('path');
app.set('view engine','html');
app.set('views',path.resolve('views'));
app.engine('html',require('ejs').__express);
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
app.use(cookieParser());
app.use(bodyParser.urlencoded({extended:true}));
app.get('/', function (req,res) {
    res.sendFile('./login.html',{root:__dirname});
});
app.post('/login', function (req,res) {
   if(req.body.username == 'admin'){
       res.cookie('username',req.body.username);
       res.cookie('password','hello');
       res.send('登陆成功');
   }else{
        res.redirect('back');
   }
});
app.listen(8080);
```
客户端根据设置的cookie自动登录
```javascript
window.onload = function () {
    var cookies = document.cookie.split('; ');
    var bb = cookies.map(item=>{
        var arr = item.split('=');
        return {name:arr[0],value:arr[1]}
    }).find(item=>{
        return 'username' ==item.name;
    });
    username.value=bb.value;
    myform.submit();
} 
``` 
## 9.cookie使用注意事项
- 可能被客户端篡改，使用前验证合法性
- 不要存储敏感数据，比如用户密码，账户余额
- 使用httpOnly保证安全
- 尽量减少cookie的体积
- 设置正确的domain和path，减少数据传输