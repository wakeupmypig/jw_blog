## 1.cookie与session区别

1. cookie数据存放在客户的浏览器上，session数据放在服务器上。
2. cookie不是很安全，别人可以分析存放在本地的COOKIE并进行COOKIE欺骗 考虑到安全应当使用session
3. session会在一定时间内保存在服务器上。当访问增多，会比较占用你服务器的性能 考虑到减轻服务器性能方面,应当使用COOKIE
4. 单个cookie保存的数据不能超过4K，很多浏览器都限制一个站点最多保存20个cookie



## 2.session的原理
1. 在服务器端生成全局唯一标识session_id
2. 在服务器内存里开辟session_id对应的数据
3. 将session_id作为标识通过cookie发送给客户端
4. 客户端在访问服务器端时将session_id发送回服务器端
5. 服务器端通过session_id取出对应的数据

```javascript
var express = require('express');
var app = express();
var cookieParser = require('cookie-parser');
app.use(cookieParser());
var sessions = {};
var SESSION_KEY = 'connect_sid';
app.get('/', function (req,res) {
    //判断用户有没有卡
    var card = req.cookies[SESSION_KEY];
    //判断有没有卡，并且现在店还有没有开
    if(card&&sessions[card]){
        sessions[card].mny-=100;
        res.send(`还有${sessions[card].mny}`);
    }else{
        //给卡的时候需要给一张唯一的卡
        var cardId = new Date()+Math.random();
        //给这个卡存钱
        sessions[cardId] = {
            mny:500
        };
        //把卡号给用户
        res.cookie(SESSION_KEY,cardId);
        //如果是新用户先给一张卡
        res.send('这是一张500元的新卡');
    }
});
app.listen(8080);
```
## 3.express中的session中间件
安装
```javascript
$ npm install express-session
```

```javascript
var express = require('express');
var app = express();
var session = require('express-session');
app.use(session({
    resave:true, //每次重新保存
    saveUninitialized:true,//保存初始化的
    secret:'jw'//密钥
}));
app.get('/', function (req,res) {
    var visit = req.session.visit;
    if(visit){
        visit++;
    }else{
        visit = 1
    }
    req.session.visit = visit;
    res.send(`第${req.session.visit}次访问`)
});
app.listen(9999);
```
参数

|参数| 描述
|----|----
|name	|设置 cookie 中，保存 session 的字段名称，默认为 connect.sid
|store	|session 的存储方式，默认存放在内存中，也可以使用 redis，mongodb 等
|secret	|通过设置的 secret 字符串，来计算 hash 值并放在 cookie 中，使产生的 signedCookie 防篡改
|cookie	|设置存放 session id 的 cookie 的相关选项，默认为 (default: { path: '/',httpOnly: true, secure: false, maxAge: null })
|genid|产生一个新的 session_id 时，所使用的函数， 默认使用 uid2 这个 npm 包
|rolling|每个请求都重新设置一个 cookie，默认为 false
|resave	|即使 session 没有被修改，也保存 session 值，默认为 true