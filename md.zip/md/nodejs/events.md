## 事件
发布订阅模式，定义对象间的一种`一对多`的依赖关系，一个发布者可以对应多个订阅者，当发布者`发生变化`的时候，他可以将消息一一通知给所有的订阅者,当一个对象的状态发生改变时，所有依赖于它的对象都`得到通知并被自动更新`。


## 1.events模块  
node中很多模块都继承自events
```javascript 
var EventEmmiter = require('events');
```
## 2.绑定事件
可以通过on方法和addListener方法绑定事件  
### 2.1 用法
```javascript
on(event,listener);
addListener(event,listener);
```
### 2.2 使用
```javascript
var EventEmmiter = require('events');
var util = require('util');
function  Girl() {}
util.inherits(Girl,EventEmmiter);
var girl = new Girl();
girl.on('帅哥来了',function () {
    console.log('喜欢帅哥');
});
``` 
## 3.发射事件
### 3.1 用法
```javascript
emit(event,args);
```
### 3.2 使用
```javascript
girl.emit('帅哥来了');
```
## 4.绑定一次事件
绑定一次,多次触发只执行一次
### 4.1 用法
```javascript
once(event,listener);
```
### 4.2 使用
```javascript
var come = function () {
    console.log('送个飞吻');
};
girl.once('帅哥来了',come);
girl.emit('帅哥来了');
girl.emit('帅哥来了');
``` 
## 5.解除监听
### 5.1 用法
```javascript
girl.removeListener(event,listener);
```
### 5.2 使用
```javascript 
girl.on('帅哥来了',come);
girl.removeListener('帅哥来了',come);
girl.emit('帅哥来了');
```
## 6.解除所有监听
通过事件名,移除事件绑定，可以通过不加参数的方式移除所有监听
### 6.1 用法
```javascript
removeAllListeners(event); 
```
### 6.2 使用
```javascript
girl.removeAllListeners('帅哥来了');
girl.removeAllListeners();
```

## 7.设置最大监听数
默认最大监听数为10,超过最大监听数会产生警告
### 7.1 用法
```javascript
setMaxListeners(count);
```
### 7.2 使用
在监听之前设置最大监听数
```javascript
setMaxListeners(3);
```
## 8.获取监听函数
### 8.1 用法
```javascript
girl.listeners(event);
```
### 8.2 使用
```javascript
girl.listeners('帅哥来了');
```
## 9.获得监听个数
### 9.1 用法
```javascript
girl.listenerCount(event);
```
### 9.2 使用
```javascript
girl.listenerCount('帅哥来了');
```

## 10.实现订阅发布
### 10.1 订阅
```javascript
Observable.prototype.on = Observable.prototype.addListener = function (event, listener) {
    if (this._events[event]) {
        this._events[event].push(listener);
    } else {
        this._events[event] = [listener];
    }
    if(this._events[event].length>this._maxListeners){
        console.error('maxListener reached!');
    }
}
```
### 10.2 发布
```javascript
Observable.prototype.emit = function(event){
    var args = Array.prototype.slice.call(arguments,1);
    if(this._events[event]){
        var listeners = this._events[event];
        listeners.forEach(function(listener){
            listener.apply(null,args);
        });
    }
}
```