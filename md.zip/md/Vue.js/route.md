## vue-router
```javascript
$ npm install vue-router
```

### 1. 路由的基本使用
```html
<div id="app">
    <a v-link="{path:'/home'}">首页</a>
    <a v-link="{path:'/user'}">用户</a>
    <router-view></router-view>
</div>
```

```javascript
var App = Vue.extend({});
var router = new VueRouter();
router.map({
    '/home': {
        component: {
            template:'<p>This is home!</p>'
        }
    },
    '/user': {
        component: {
            template:'<p>This is user!</p>'
        }
    }
});
router.start(App, '#app');
``` 